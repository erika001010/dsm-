public class TaskAdapter {
}
